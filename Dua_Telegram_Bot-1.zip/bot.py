import os
import sqlite3
from datetime import date
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application, CommandHandler, CallbackQueryHandler,
    ContextTypes, MessageHandler, filters
)

TOKEN = os.getenv("BOT_TOKEN")
DB = "dua.db"

def connect():
    return sqlite3.connect(DB)

def init_db():
    con = connect()
    con.execute("""
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            username TEXT DEFAULT '',
            coins INTEGER DEFAULT 100,
            last_daily TEXT DEFAULT ''
        )
    """)
    con.commit()
    con.close()

def ensure_user(user):
    con = connect()
    con.execute(
        "INSERT OR IGNORE INTO users(user_id, username) VALUES (?, ?)",
        (user.id, user.username or "")
    )
    con.execute(
        "UPDATE users SET username=? WHERE user_id=?",
        (user.username or "", user.id)
    )
    con.commit()
    con.close()

def get_user(user_id):
    con = connect()
    row = con.execute(
        "SELECT user_id, username, coins, last_daily FROM users WHERE user_id=?",
        (user_id,)
    ).fetchone()
    con.close()
    return row

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    ensure_user(update.effective_user)
    keyboard = [
        [InlineKeyboardButton("🎮 Games", callback_data="games"),
         InlineKeyboardButton("💰 Economy", callback_data="economy")],
        [InlineKeyboardButton("👤 Profile", callback_data="profile"),
         InlineKeyboardButton("🏆 Leaderboard", callback_data="leaderboard")],
    ]
    await update.message.reply_text(
        "🌸 Welcome to Dua!\n\n"
        "♟️ Chess • 🎲 LUDO • 🃏 UNO\n"
        "🔤 Word Games • 👥 Group Games\n"
        "💰 Economy • 💬 Chat with Dua\n\n"
        "Choose an option:",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

async def help_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "🌸 Dua Commands\n\n"
        "/start - Main menu\n"
        "/games - Games\n"
        "/balance - Your coins\n"
        "/daily - Daily reward\n"
        "/profile - Your profile\n"
        "/leaderboard - Top players\n"
        "/help - Help"
    )

async def balance(update: Update, context: ContextTypes.DEFAULT_TYPE):
    ensure_user(update.effective_user)
    row = get_user(update.effective_user.id)
    await update.message.reply_text(f"💰 Balance: {row[2]} coins")

async def daily(update: Update, context: ContextTypes.DEFAULT_TYPE):
    ensure_user(update.effective_user)
    uid = update.effective_user.id
    row = get_user(uid)
    today = str(date.today())
    if row[3] == today:
        await update.message.reply_text("⏳ You already collected today's reward.")
        return
    reward = 100
    con = connect()
    con.execute(
        "UPDATE users SET coins=coins+?, last_daily=? WHERE user_id=?",
        (reward, today, uid)
    )
    con.commit()
    con.close()
    await update.message.reply_text(f"🎁 Daily reward: +{reward} coins!")

async def profile(update: Update, context: ContextTypes.DEFAULT_TYPE):
    ensure_user(update.effective_user)
    row = get_user(update.effective_user.id)
    name = f"@{row[1]}" if row[1] else "Player"
    await update.message.reply_text(
        f"👤 Dua Profile\n\n{name}\n🆔 {row[0]}\n💰 {row[2]} coins"
    )

async def leaderboard(update: Update, context: ContextTypes.DEFAULT_TYPE):
    con = connect()
    rows = con.execute(
        "SELECT username, coins FROM users ORDER BY coins DESC LIMIT 10"
    ).fetchall()
    con.close()
    text = "🏆 Dua Leaderboard\n\n"
    for i, (username, coins) in enumerate(rows, 1):
        name = f"@{username}" if username else "Player"
        text += f"{i}. {name} — 💰 {coins}\n"
    await update.message.reply_text(text)

async def games(update: Update, context: ContextTypes.DEFAULT_TYPE):
    keyboard = [
        [InlineKeyboardButton("♟️ Chess", callback_data="chess"),
         InlineKeyboardButton("🎲 LUDO", callback_data="ludo")],
        [InlineKeyboardButton("🃏 UNO", callback_data="uno"),
         InlineKeyboardButton("🔤 Word", callback_data="word")],
    ]
    await update.message.reply_text(
        "🎮 Dua Games\n\nChoose a game:",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

async def buttons(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()

    if q.data == "games":
        keyboard = [
            [InlineKeyboardButton("♟️ Chess", callback_data="chess"),
             InlineKeyboardButton("🎲 LUDO", callback_data="ludo")],
            [InlineKeyboardButton("🃏 UNO", callback_data="uno"),
             InlineKeyboardButton("🔤 Word", callback_data="word")],
        ]
        await q.edit_message_text(
            "🎮 Dua Games", reply_markup=InlineKeyboardMarkup(keyboard)
        )
    elif q.data == "economy":
        await q.edit_message_text(
            "💰 Economy\n\n/balance — Balance\n/daily — Daily reward\n"
            "/leaderboard — Leaderboard"
        )
    elif q.data == "profile":
        ensure_user(q.from_user)
        row = get_user(q.from_user.id)
        await q.edit_message_text(
            f"👤 Profile\n\n🆔 {row[0]}\n💰 {row[2]} coins"
        )
    elif q.data == "leaderboard":
        con = connect()
        rows = con.execute(
            "SELECT username, coins FROM users ORDER BY coins DESC LIMIT 10"
        ).fetchall()
        con.close()
        text = "🏆 Leaderboard\n\n"
        for i, (username, coins) in enumerate(rows, 1):
            text += f"{i}. @{username if username else 'Player'} — {coins}\n"
        await q.edit_message_text(text)
    else:
        names = {
            "chess": "♟️ Chess",
            "ludo": "🎲 LUDO",
            "uno": "🃏 UNO",
            "word": "🔤 Word Games",
        }
        await q.edit_message_text(
            f"{names.get(q.data, 'Game')} is ready for the next game module."
        )

async def chat(update: Update, context: ContextTypes.DEFAULT_TYPE):
    ensure_user(update.effective_user)
    await update.message.reply_text(
        "🌸 Dua: I received your message!\n\n"
        "AI chat can be connected here using your preferred AI API."
    )

def main():
    if not TOKEN:
        raise RuntimeError("Set BOT_TOKEN before starting the bot.")
    init_db()
    app = Application.builder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_cmd))
    app.add_handler(CommandHandler("balance", balance))
    app.add_handler(CommandHandler("daily", daily))
    app.add_handler(CommandHandler("profile", profile))
    app.add_handler(CommandHandler("leaderboard", leaderboard))
    app.add_handler(CommandHandler("games", games))
    app.add_handler(CallbackQueryHandler(buttons))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, chat))
    print("Dua bot is running...")
    app.run_polling()

if __name__ == "__main__":
    main()
